"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var employee_component_1 = require("./employee.component");
var myservice_1 = require("./myservice");
var MyForm = (function () {
    function MyForm(mser) {
        this.mser = mser;
        this.empList = [];
        this.emp = { empNo: 0, empName: "", salary: 0, dept: "" };
    }
    MyForm.prototype.ngOnInit = function () {
        var _this = this;
        //this.empList= this.mser.getAllEmp();
        this.mser.getAllEmp().subscribe(function (result) { return _this.empList = result; });
        this.mser.getFromSpring().subscribe(function (res) { return _this.newEmpList = res; });
    };
    MyForm.prototype.submitData = function (frm1) {
        var empno = frm1.controls['txtEmpNo'].value;
        var ename = frm1.controls['txtEmpName'].value;
        var sal = frm1.controls['txtSalary'].value;
        var dept = frm1.controls['txtDept'].value;
        var e = new employee_component_1.Employee(empno, ename, sal, dept);
        this.empList.push(e);
    };
    return MyForm;
}());
MyForm = __decorate([
    core_1.Component({
        selector: "my-form",
        templateUrl: './myform.component.html',
        providers: [myservice_1.Myservice]
    }),
    __metadata("design:paramtypes", [myservice_1.Myservice])
], MyForm);
exports.MyForm = MyForm;
